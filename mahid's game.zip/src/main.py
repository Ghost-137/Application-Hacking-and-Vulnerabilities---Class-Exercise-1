import pygame

class MyGame:
    def __init__(self):
        pygame.init()
        
        self.load_images()
        self.new_game()
        
        self.height = len(self.map)
        self.width = len(self.map[0])
        self.scale = self.images[0].get_width()

        window_height = self.scale * self.height
        window_width = self.scale * self.width
        self.window = pygame.display.set_mode((window_width, window_height + self.scale))

        self.game_font = pygame.font.SysFont("Arial", 24)

        pygame.display.set_caption("Robot Adventure")

        self.main_loop()

    def load_images(self):
        self.images = []
        self.images.append(pygame.image.load("coin.png"))    
        self.images.append(pygame.image.load("door.png"))    
        self.images.append(pygame.image.load("monster.png")) 
        self.images.append(pygame.image.load("robot.png")) 

    def new_game(self):
        self.map = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 1, 0, 2, 0, 0, 2, 0, 0, 0, 3, 2, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 2, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                    [0, 2, 3, 0, 0, 0, 2, 0, 0, 0, 0, 4, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
        self.points = 0
        self.state = "RUNNING" 

    def main_loop(self):
        while True:
            self.check_events()
            self.draw_window()

    def check_events(self):
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if self.state == "RUNNING":
                    if event.key == pygame.K_LEFT:
                        self.move(0, -1)
                    if event.key == pygame.K_RIGHT:
                        self.move(0, 1)
                    if event.key == pygame.K_UP:
                        self.move(-1, 0)
                    if event.key == pygame.K_DOWN:
                        self.move(1, 0)
                
                if event.key == pygame.K_F2:
                    self.new_game()
                if event.key == pygame.K_ESCAPE:
                    exit()

            if event.type == pygame.QUIT:
                exit()

    def find_robot(self):
        for y in range(self.height):
            for x in range(self.width):
                if self.map[y][x] == 1:
                    return (y, x)
        return (0, 0)

    def move(self, move_y, move_x):
        robot_y, robot_x = self.find_robot()
        target_y = robot_y + move_y
        target_x = robot_x + move_x

        if target_x < 0 or target_x >= self.width or target_y < 0 or target_y >= self.height:
            return

        target_cell = self.map[target_y][target_x]
        if target_cell == 3:
            self.state = "LOST"
            return

        if target_cell == 2:
            self.points += 1
            self.map[robot_y][robot_x] = 0
            self.map[target_y][target_x] = 1

        elif target_cell == 4:
            self.map[robot_y][robot_x] = 0
            self.map[target_y][target_x] = 1
            self.state = "WON"
            
        elif target_cell == 0:
            self.map[robot_y][robot_x] = 0
            self.map[target_y][target_x] = 1

    def draw_window(self):
        self.window.fill((0, 0, 0))

        for y in range(self.height):
            for x in range(self.width):
                cell = self.map[y][x]
                if cell == 1:
                    self.window.blit(self.images[3], (x * self.scale, y * self.scale))
                elif cell == 2: 
                    self.window.blit(self.images[0], (x * self.scale, y * self.scale))
                elif cell == 3: 
                    self.window.blit(self.images[2], (x * self.scale, y * self.scale))
                elif cell == 4:
                    self.window.blit(self.images[1], (x * self.scale, y * self.scale))

        
        text_color = (255, 255, 255)
        game_text = self.game_font.render(f"Points: {self.points}", True, text_color)
        self.window.blit(game_text, (25, self.height * self.scale + 10))

        if self.state == "WON":
            win_text = self.game_font.render("YOU WON! (F2 to Restart)", True, (0, 255, 0))
            self.window.blit(win_text, (200, self.height * self.scale + 10))
        elif self.state == "LOST":
            lose_text = self.game_font.render("YOU DIED! (F2 to Restart)", True, (255, 0, 0))
            self.window.blit(lose_text, (200, self.height * self.scale + 10))

        pygame.display.flip()

if __name__ == "__main__":
    MyGame()